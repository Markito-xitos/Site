from flask import Flask, jsonify
import uuid

app = Flask(__name__)
keys = []

@app.route('/generate_key', methods=['GET'])
def generate_key():
    new_key = str(uuid.uuid4())
    keys.append(new_key)
    return jsonify({'key': new_key})

@app.route('/validate_key/<key>', methods=['GET'])
def validate_key(key):
    return jsonify({'valid': key in keys})

if __name__ == '__main__':
    app.run(debug=True)