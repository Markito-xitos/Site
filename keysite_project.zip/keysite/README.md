# Gerador de Keys

Um site simples feito com Flask para gerar e validar chaves de acesso.

## Como rodar

1. Instale as dependências:
```
pip install -r requirements.txt
```

2. Inicie o servidor:
```
python app.py
```

3. Acesse `http://127.0.0.1:5000` no navegador.

## Endpoints

- `/generate_key` - Gera uma nova key.
- `/validate_key/<key>` - Valida se a key é válida.